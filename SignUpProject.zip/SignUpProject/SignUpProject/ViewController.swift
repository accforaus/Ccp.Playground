//
//  ViewController.swift
//  SignUpProject
//
//  Created by cscoi049 on 2019. 8. 7..
//  Copyright © 2019년 SU. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var idField: UITextField!
    @IBOutlet var passwordField: UITextField!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        idField.text = UserInformation.shared.id
        passwordField.text = ""
    }

    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

