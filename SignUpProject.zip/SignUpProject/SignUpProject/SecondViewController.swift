//
//  SecondViewController.swift
//  SignUpProject
//
//  Created by cscoi049 on 2019. 8. 7..
//  Copyright © 2019년 SU. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet var idField: UITextField!
    @IBOutlet var passwordField: UITextField!
    @IBOutlet var passwordCheckField: UITextField!
    @IBOutlet var introduce: UITextView!
    @IBOutlet var nextButton: UIButton!
    var imageDidGetSelected: Bool = false
    
    @IBAction func tapView(_ sender: UITapGestureRecognizer) {
        self.present(self.imagePicker, animated: true, completion: nil)
    }
    
    lazy var imagePicker: UIImagePickerController = {
        let picker: UIImagePickerController = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.allowsEditing = true
        picker.delegate = self
        return picker
    }()
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let editedImage: UIImage = info[UIImagePickerControllerEditedImage] as? UIImage {
            self.imageView.image = editedImage
            imageDidGetSelected = true
            determineButtonState()
        }
        
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func dismissModal() {
        idField = nil
        passwordField = nil
        passwordCheckField = nil
        
        self.dismiss(animated: true, completion: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        idField.delegate = self
        passwordField.delegate = self
        passwordCheckField.delegate = self
        
        idField.text = UserInformation.shared.id

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func determineButtonState() {
        if let id: String = idField.text, id.count > 0,
            let password: String = passwordField.text, password.count > 0,
            let passwordCheck: String = passwordCheckField.text, passwordCheck == password,
            imageDidGetSelected == true,
            let textField: UITextView = introduce, textField.text.count > 0 {
            nextButton.isEnabled = true
            UserInformation.shared.id = id
            UserInformation.shared.password = password
            UserInformation.shared.passwordCheck = passwordCheck
        } else {
            nextButton.isEnabled = false
        }
    }

       @IBAction func textFieldDidEndEditing(_ textField: UITextField) {
            determineButtonState()
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
