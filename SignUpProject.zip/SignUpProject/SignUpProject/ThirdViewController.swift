//
//  ThirdViewController.swift
//  SignUpProject
//
//  Created by cscoi049 on 2019. 8. 8..
//  Copyright © 2019년 SU. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet var joinButton: UIButton!
    
    @IBAction func joinSucess() {
        self.dismiss(animated: true, completion: nil)
    }

    @IBAction func textFieldDidEndEditing(_ textField: UITextField) {
        determineButtonState()
        
        let phoneNumber: String = self.phoneNumberTextField.text!
        UserInformation.shared.phoneNumber = phoneNumber
    }
    
    let dateFormatter: DateFormatter = {
        let formatter: DateFormatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter
    }()
    
    @IBAction func didDatePickerValueChanged(_ sender: UIDatePicker) {
        determineButtonState()
        
        let date: Date = self.datePicker.date
        let dateString: String = self.dateFormatter.string(from: date)
        
        self.dateLabel.text = dateString
        UserInformation.shared.birthday = self.dateLabel.text
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        phoneNumberTextField.text = UserInformation.shared.phoneNumber
        dateLabel.text = UserInformation.shared.birthday
        
        phoneNumberTextField.delegate = self

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func popToPrev() {
        UserInformation.shared.phoneNumber = phoneNumberTextField.text
        UserInformation.shared.birthday = dateLabel.text
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func dismissModal() {
        UserInformation.shared.id = nil
        UserInformation.shared.password = nil
        UserInformation.shared.passwordCheck = nil
        UserInformation.shared.phoneNumber = nil
        UserInformation.shared.birthday = nil
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func determineButtonState() {
        if dateLabel.text != nil, let phoneNumber = phoneNumberTextField.text, phoneNumber.count > 0 {
            joinButton.isEnabled = true
        } else {
            joinButton.isEnabled = false
        }
    }

    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
