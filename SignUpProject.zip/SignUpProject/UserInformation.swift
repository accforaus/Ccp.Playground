//
//  UserInformation.swift
//  SignUpProject
//
//  Created by cscoi049 on 2019. 8. 8..
//  Copyright © 2019년 SU. All rights reserved.
//

import UIKit

class UserInformation: NSObject {

    var id: String?
    var password: String?
    var passwordCheck: String?
    var introduceText: String?
    var phoneNumber: String?
    var birthday: String?
    
    
    static let shared: UserInformation = UserInformation()
}
